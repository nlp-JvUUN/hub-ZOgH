"""
BertNER（线性头）和 BertCRFNER（CRF头）两个模型

教学重点：
  1. 线性头（BertNER）：每个 token 独立预测标签
     - 问题：softmax 的独立预测忽略标签间的依赖关系
     - 可能产生非法序列：B-name 后接 I-company，I-name 开头等

  2. CRF 层（BertCRFNER）：加入转移矩阵，全局最优解码
     - 转移矩阵学习"什么标签之后可以接什么标签"
     - Viterbi 算法保证输出合法序列，永远不会 B-name 后接 I-company
     - 代价：训练时需要前向-后向算法，比线性头慢约 20~30%

  3. 两者区别的量化：evaluate.py 会统计非法序列数

依赖：
  pip install pytorch-crf

"""

import torch.nn as nn
from transformers import BertModel
from torchcrf import CRF


class BertNER(nn.Module):
    """
    BERT + 线性层（独立预测）
    每个token独立通过softmax预测标签
    """

    def __init__(self, pretrained_model_path: str, num_tags: int, dropout: float = 0.1):
        """
        Args:
            pretrained_model_path: BERT预训练模型路径
            num_tags: 标签数量
            dropout: dropout概率
        """
        super().__init__()
        self.bert = BertModel.from_pretrained(pretrained_model_path)
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(self.bert.config.hidden_size, num_tags)
        self.num_tags = num_tags

    def forward(self, input_ids, attention_mask, labels=None):
        """
        Args:
            input_ids: 输入token ids
            attention_mask: 注意力掩码
            labels: 标签（用于计算损失）

        Returns:
            如果labels不为None，返回(loss, logits)
            否则返回logits
        """
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            return_dict=True,
        )
        sequence_output = outputs.last_hidden_state  # (batch, seq_len, hidden)
        sequence_output = self.dropout(sequence_output)
        logits = self.classifier(sequence_output)  # (batch, seq_len, num_tags)

        if labels is not None:
            loss_fct = nn.CrossEntropyLoss(ignore_index=-100)
            loss = loss_fct(logits.view(-1, self.num_tags), labels.view(-1))
            return loss, logits
        return logits


class BertCRFNER(nn.Module):
    """
    BERT + CRF层（全局最优解码）
    通过CRF层学习标签间的转移关系，保证输出合法序列
    """

    def __init__(self, pretrained_model_path: str, num_tags: int, dropout: float = 0.1):
        """
        Args:
            pretrained_model_path: BERT预训练模型路径
            num_tags: 标签数量
            dropout: dropout概率
        """
        super().__init__()
        self.bert = BertModel.from_pretrained(pretrained_model_path)
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(self.bert.config.hidden_size, num_tags)
        self.crf = CRF(num_tags, batch_first=True)
        self.num_tags = num_tags

    def forward(self, input_ids, attention_mask, labels=None):
        """
        Args:
            input_ids: 输入token ids
            attention_mask: 注意力掩码
            labels: 标签（用于计算损失）

        Returns:
            如果labels不为None，返回(loss, decoded)
            否则返回decoded
        """
        outputs = self.bert(
            input_ids=input_ids, 
            attention_mask=attention_mask,
            return_dict=True,
        )
        sequence_output = outputs.last_hidden_state
        sequence_output = self.dropout(sequence_output)
        emissions = self.classifier(sequence_output)  # (batch, seq_len, num_tags)

        if labels is not None:
            # CRF需要将-100的位置mask掉
            labels_masked = labels.clone()
            labels_masked[labels == -100] = 0  # 用0替代，但实际这些位置会被mask

            # 创建attention_mask对应的 CRF mask
            mask = attention_mask.bool()

            loss = self.crf(emissions, labels_masked, mask=mask, reduction='mean')
            # 取负数因为CRF的forward返回的是负对数似然
            loss = -loss

            if self.training:
                return loss, None
            else:
                decoded = self.crf.decode(emissions, mask=mask)
                return loss, decoded
        else:
            decoded = self.crf.decode(emissions, mask=attention_mask.bool())
            return decoded