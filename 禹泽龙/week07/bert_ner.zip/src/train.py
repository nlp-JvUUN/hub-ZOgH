"""
BertNER（线性头）和 BertCRFNER（CRF头）两个模型

教学重点：
  1. 线性头（BertNER）：每个 token 独立预测标签
     - 问题：softmax 的独立预测忽略标签间的依赖关系
     - 可能产生非法序列：B-name 后接 I-company，I-name 开头等

  2. CRF 层（BertCRFNER）：加入转移矩阵，全局最优解码
     - 转移矩阵学习"什么标签之后可以接什么标签"
     - Viterbi 算法保证输出合法序列，永远不会 B-name 后接 I-company
     - 代价：训练时需要前向-后向算法，比线性头慢约 20~30%

  3. 两者区别的量化：evaluate.py 会统计非法序列数

  4.训练时保存模型的训练数据，对比模型时使用
"""

import os
import json
import time
import torch
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import LambdaLR
from transformers import BertTokenizerFast
from seqeval.metrics import f1_score
from tqdm import tqdm

from model import BertNER, BertCRFNER
from dataset import NERDataset, collate_fn


def get_optimizer_with_layerwise_lr(model, bert_lr=2e-5, classifier_lr_multiplier=5.0, weight_decay=0.01):
    """
    创建分层学习率优化器
    - BERT层: bert_lr (默认2e-5)
    - 分类头: bert_lr * classifier_lr_multiplier (默认1e-4)
    """
    # BERT层参数
    bert_params = []
    # 分类层参数
    classifier_params = []

    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if 'classifier' in name or 'crf' in name:
            classifier_params.append(param)
        else:
            bert_params.append(param)

    optimizer_grouped_parameters = [
        # BERT层
        {
            'params': bert_params,
            'lr': bert_lr,
            'weight_decay': weight_decay,
        },
        # 分类头
        {
            'params': classifier_params,
            'lr': bert_lr * classifier_lr_multiplier,
            'weight_decay': weight_decay,
        },
    ]

    return torch.optim.AdamW(optimizer_grouped_parameters)


def get_linear_warmup_scheduler(optimizer, num_warmup_steps, num_training_steps):
    """线性预热+线性衰减调度器"""
    def lr_lambda(current_step):
        if current_step < num_warmup_steps:
            return float(current_step) / float(max(1, num_warmup_steps))
        return max(0.0, 1.0 - (current_step - num_warmup_steps) / float(max(1, num_training_steps - num_warmup_steps)))

    return LambdaLR(optimizer, lr_lambda)


def train_one_epoch(model, dataloader, optimizer, scheduler, device, grad_accum=1):
    """训练一个epoch，支持梯度累计和学习率调度"""
    model.train()
    total_loss = 0
    optimizer.zero_grad()

    for step, batch in enumerate(tqdm(dataloader, desc="Training")):
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        labels = batch['labels'].to(device)

        if isinstance(model, BertCRFNER):
            loss, _ = model(input_ids, attention_mask, labels)
        else:
            loss, _ = model(input_ids, attention_mask, labels)

        # 梯度累计：loss除以累计步数
        loss = loss / grad_accum
        loss.backward()

        # 梯度累计完成，执行优化器步骤
        if (step + 1) % grad_accum == 0 or (step + 1) == len(dataloader):
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad()

        total_loss += loss.item() * grad_accum

    return total_loss / len(dataloader)


def evaluate_epoch(model, dataloader, id2tag, device, use_crf):
    """在验证集上评估，返回entity-level的F1"""
    model.eval()
    all_true_tags = []
    all_pred_tags = []
    total_loss = 0

    with torch.no_grad():
        for batch in tqdm(dataloader, desc="Evaluating"):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].to(device)  # keep as tensor, move to device

            if use_crf:
                loss, decoded = model(input_ids, attention_mask, labels)
                predictions = decoded
            else:
                loss, logits = model(input_ids, attention_mask, labels)
                predictions = torch.argmax(logits, dim=-1).cpu().numpy()

            labels_np = labels.cpu().numpy()

            for i in range(input_ids.size(0)):
                seq_labels = labels_np[i]
                seq_preds = predictions[i] if i < len(predictions) else []

                true_tags = []
                pred_tags = []
                for lbl, pred in zip(seq_labels, seq_preds):
                    if lbl != -100:
                        true_tags.append(id2tag.get(lbl, 'O'))
                        pred_tags.append(id2tag.get(pred, 'O'))

                if len(true_tags) > 0:
                    all_true_tags.append(true_tags)
                    all_pred_tags.append(pred_tags)

            total_loss += loss.item() if isinstance(loss, torch.Tensor) else loss

    # 计算entity-level F1
    f1 = f1_score(all_true_tags, all_pred_tags)
    avg_loss = total_loss / len(dataloader)

    return avg_loss, f1


def train(args):
    """训练入口"""
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    # 创建输出目录
    log_dir = '../outputs/logs'
    os.makedirs(log_dir, exist_ok=True)

    # 加载tokenizer和数据集
    tokenizer = BertTokenizerFast.from_pretrained(args.pretrained_model_path)

    train_dataset = NERDataset(
        data_path=args.train_data_path,
        tokenizer=tokenizer,
        max_length=args.max_length
    )

    val_dataset = NERDataset(
        data_path=args.val_data_path,
        tokenizer=tokenizer,
        max_length=args.max_length
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        collate_fn=collate_fn,
        num_workers=2
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        collate_fn=collate_fn,
        num_workers=2
    )

    # 创建模型
    num_tags = len(train_dataset.tags)
    if args.use_crf:
        model = BertCRFNER(args.pretrained_model_path, num_tags, args.dropout)
    else:
        model = BertNER(args.pretrained_model_path, num_tags, args.dropout)

    model = model.to(device)

    # 分层学习率优化器: BERT 2e-5, 分类头 2e-5*5.0
    optimizer = get_optimizer_with_layerwise_lr(
        model,
        bert_lr=args.learning_rate,
        classifier_lr_multiplier=args.classifier_lr_multiplier,
        weight_decay=args.weight_decay
    )

    # 学习率调度器 (warmup + linear decay)
    total_steps = len(train_loader) * args.num_epochs // args.grad_accum
    warmup_steps = int(total_steps * args.warmup_ratio)
    scheduler = get_linear_warmup_scheduler(optimizer, warmup_steps, total_steps)

    # 训练循环
    best_f1 = 0.0
    log_records = []

    # 模型保存路径
    ckpt_path = os.path.join(args.output_dir, f"{args.model_name}_best.pt")
    os.makedirs(args.output_dir, exist_ok=True)

    print(f"\n开始训练（{'BERT+CRF' if args.use_crf else 'BERT+Linear'}）...")

    for epoch in range(1, args.num_epochs + 1):
        t0 = time.time()
        train_loss = train_one_epoch(model, train_loader, optimizer, scheduler, device, args.grad_accum)
        val_loss, val_f1 = evaluate_epoch(model, val_loader, train_dataset.id2tag, device, args.use_crf)
        elapsed = time.time() - t0

        print(
            f"Epoch {epoch}/{args.num_epochs} | "
            f"train_loss={train_loss:.4f} | "
            f"val_loss={val_loss:.4f} | "
            f"val_entity_f1={val_f1:.4f} | "
            f"time={elapsed:.0f}s"
        )

        log_records.append({
            "epoch": epoch,
            "train_loss": round(train_loss, 6),
            "val_loss": round(val_loss, 6),
            "val_entity_f1": round(val_f1, 6),
            "elapsed_s": round(elapsed, 1),
        })

        if val_f1 > best_f1:
            best_f1 = val_f1
            torch.save({
                'epoch': epoch,
                'use_crf': args.use_crf,
                'state_dict': model.state_dict(),
                'val_entity_f1': val_f1,
                'tags': train_dataset.tags,
                'tag2id': train_dataset.tag2id,
                'id2tag': train_dataset.id2tag,
                'args': vars(args),
            }, ckpt_path)
            print(f"  ★ 新最优 F1={val_f1:.4f}，已保存 → {ckpt_path}")

    # 保存训练日志
    model_type = 'crf' if args.use_crf else 'linear'
    log_path = os.path.join(log_dir, f"train_{model_type}_log.json")
    with open(log_path, 'w', encoding='utf-8') as f:
        json.dump(log_records, f, ensure_ascii=False, indent=2)

    print(f"\n训练完成！最优 val_entity_f1={best_f1:.4f}")
    print(f"  Checkpoint: {ckpt_path}")
    print(f"  训练日志:   {log_path}")
    print(f"\n下一步：python evaluate.py {'--use_crf' if args.use_crf else ''}")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Train BERT NER model')
    parser.add_argument('--pretrained_model_path', type=str,
                        default='../pretrain_models/bert-base-chinese',
                        help='Pretrained BERT model path')
    parser.add_argument('--train_data_path', type=str,
                        default='../data/train.json',
                        help='Training data path')
    parser.add_argument('--val_data_path', type=str,
                        default='../data/validation.json',
                        help='Validation data path')
    parser.add_argument('--output_dir', type=str,
                        default='../outputs/models',
                        help='Output directory')
    parser.add_argument('--model_name', type=str,
                        default='bert_ner',
                        help='Model name for saving')
    parser.add_argument('--use_crf', action='store_true',
                        help='Use CRF layer')
    parser.add_argument('--max_length', type=int, default=128,
                        help='Max sequence length')
    parser.add_argument('--batch_size', type=int, default=16,
                        help='Batch size')
    parser.add_argument('--num_epochs', type=int, default=3,
                        help='Number of epochs')
    parser.add_argument('--learning_rate', type=float, default=2e-5,
                        help='BERT learning rate (default: 2e-5)')
    parser.add_argument('--classifier_lr_multiplier', type=float, default=5.0,
                        help='Classifier head learning rate multiplier (default: 5.0)')
    parser.add_argument('--warmup_ratio', type=float, default=0.1,
                        help='Warmup ratio for learning rate scheduler (default: 0.1)')
    parser.add_argument('--grad_accum', type=int, default=1,
                        help='Gradient accumulation steps (default: 1)')
    parser.add_argument('--weight_decay', type=float, default=0.01,
                        help='Weight decay (default: 0.01)')
    parser.add_argument('--dropout', type=float, default=0.1,
                        help='Dropout rate')

    args = parser.parse_args()

    train(args)