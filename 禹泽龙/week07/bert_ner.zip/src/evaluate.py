"""
在测试集上评估 BERT NER 模型，并统计非法序列

教学重点：
  1. seqeval 的 entity-level 评估（与 token-level 的区别）
     - token-level：逐个 token 算对错（O 标签太多，accuracy 虚高）
     - entity-level：整个实体span必须完全匹配才算对（更严格，更有意义）
  2. 非法序列统计：量化 CRF vs 线性头的关键差异
     - 非法：I-X 在序列开头，或 B-X 后面跟 I-Y（X≠Y）
     - 线性头通常有几十到几百条非法序列，CRF 始终为 0
  3. 逐类型 F1 分析：哪类实体最难识别

使用方式：
  python evaluate.py                        # 评估 BERT+Linear
  python evaluate.py --use_crf              # 评估 BERT+CRF
  python evaluate.py --split validation     # 在验证集上评估
"""

import os
import json
import torch
from torch.utils.data import DataLoader
from transformers import BertTokenizerFast
from seqeval.metrics import classification_report, f1_score, precision_score, recall_score
from tqdm import tqdm

from model import BertNER, BertCRFNER
from dataset import NERDataset, collate_fn


def analyze_illegal_sequence(tags):
    """
    分析一个标签序列是否非法及非法类型

    返回:
        (is_illegal, illegal_start, illegal_transition)
        - is_illegal: 是否非法
        - illegal_start: 是否为非法开头（I-X开头）
        - illegal_transition: 是否有非法转移（B-X/I-X → I-Y, X≠Y）
    """
    if len(tags) == 0:
        return False, False, False

    illegal_start = False
    illegal_transition = False

    # 检查是否以I-开头
    if tags[0].startswith('I-'):
        illegal_start = True

    # 检查B-X后面是否跟I-Y（X≠Y）
    prev_bio = 'O'
    prev_entity_type = None

    for i, tag in enumerate(tags):
        if tag == 'O':
            prev_bio = 'O'
            prev_entity_type = None
        elif tag.startswith('B-'):
            entity_type = tag[2:]
            prev_bio = 'B-'
            prev_entity_type = entity_type
        elif tag.startswith('I-'):
            entity_type = tag[2:]
            if prev_entity_type is None:
                # I-X前面没有任何B-或I-，非法开头
                illegal_start = True
            elif prev_entity_type != entity_type:
                # B-X/I-X后面接了I-Y（X≠Y），非法转移
                illegal_transition = True
            prev_bio = 'I-'
            prev_entity_type = entity_type

    is_illegal = illegal_start or illegal_transition
    return is_illegal, illegal_start, illegal_transition


def compute_illegal_stats(all_sequences):
    """计算所有序列的非法统计"""
    total = len(all_sequences)
    illegal_start_count = 0
    illegal_transition_count = 0
    total_illegal = 0

    for seq in all_sequences:
        is_illegal, illegal_start, illegal_transition = analyze_illegal_sequence(seq)
        if is_illegal:
            total_illegal += 1
            if illegal_start:
                illegal_start_count += 1
            if illegal_transition:
                illegal_transition_count += 1

    return {
        'total_seqs': total,
        'illegal_start': illegal_start_count,
        'illegal_transition': illegal_transition_count,
        'total_illegal': total_illegal,
    }


def group_tags_to_entities(tags):
    """将BIO标签序列转换为实体列表"""
    entities = []
    current_entity = None
    current_type = None

    for tag in tags:
        if tag == 'O':
            if current_entity is not None:
                entities.append((current_type, current_entity))
                current_entity = None
                current_type = None
        elif tag.startswith('B-'):
            if current_entity is not None:
                entities.append((current_type, current_entity))
            current_entity = [tag]
            current_type = tag[2:]
        elif tag.startswith('I-'):
            if current_entity is not None:
                current_entity.append(tag)

    if current_entity is not None:
        entities.append((current_type, current_entity))

    return entities


def evaluate(args):
    """评估入口"""
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    # 加载tokenizer
    tokenizer = BertTokenizerFast.from_pretrained(args.pretrained_model_path)

    # 加载数据集
    data_path = os.path.join('../data', f'{args.split}.json')
    dataset = NERDataset(
        data_path=data_path,
        tokenizer=tokenizer,
        max_length=args.max_length
    )

    dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        collate_fn=collate_fn,
        num_workers=2
    )

    # 加载模型
    num_tags = len(dataset.tags)
    if args.use_crf:
        model = BertCRFNER(args.pretrained_model_path, num_tags, args.dropout)
    else:
        model = BertNER(args.pretrained_model_path, num_tags, args.dropout)

    # 加载训练好的权重
    model_path = os.path.join(args.model_dir, f"{args.model_name}_best.pt")
    checkpoint = torch.load(model_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint['state_dict'])
    model = model.to(device)
    model.eval()

    print(f"Loaded model from {model_path}")

    # 收集预测和标签
    all_true_sequences = []  # entity-level
    all_pred_sequences = []
    all_true_tags = []  # token-level
    all_pred_tags = []
    all_pred_tag_sequences = []  # 用于非法序列统计

    with torch.no_grad():
        for batch in tqdm(dataloader, desc="Evaluating"):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].cpu().numpy()

            if args.use_crf:
                decoded = model(input_ids, attention_mask)
                # decoded: list of list of int
                predictions = decoded
            else:
                logits = model(input_ids, attention_mask)
                predictions = torch.argmax(logits, dim=-1).cpu().numpy()

            # 处理每个样本
            for i in range(input_ids.size(0)):
                seq_labels = labels[i]
                seq_preds = predictions[i] if i < len(predictions) else []

                # 提取有效位置的标签（不是-100）
                true_tags = []
                pred_tags = []

                for lbl, pred in zip(seq_labels, seq_preds):
                    if lbl != -100:
                        true_tags.append(dataset.id2tag.get(lbl, 'O'))
                        pred_tags.append(dataset.id2tag.get(pred, 'O'))

                if len(true_tags) > 0:
                    all_true_tags.append(true_tags)
                    all_pred_tags.append(pred_tags)
                    all_pred_tag_sequences.append(pred_tags)

                    # entity-level
                    true_entities = group_tags_to_entities(true_tags)
                    pred_entities = group_tags_to_entities(pred_tags)
                    all_true_sequences.append(true_entities)
                    all_pred_sequences.append(pred_entities)

    # 计算非法序列统计
    illegal_stats = compute_illegal_stats(all_pred_tag_sequences)

    # 计算指标
    print("\n" + "="*60)
    print("Entity-Level Evaluation (seqeval)")
    print("="*60)

    # 非法序列统计
    print(f"\n【非法 BIO 序列统计】")
    print(f"  总序列数：{illegal_stats['total_seqs']}")
    print(f"  非法开头（I-X 开头）：{illegal_stats['illegal_start']} 条")
    print(f"  非法转移（B-X/I-X → I-Y, X≠Y）：{illegal_stats['illegal_transition']} 条")
    print(f"  合计非法序列：{illegal_stats['total_illegal']} 条")

    # seqeval的分类报告
    report = classification_report(
        all_true_tags,
        all_pred_tags,
        digits=4,
        output_dict=True
    )

    print(f"\nClassification Report:")
    for tag, metrics in report.items():
        if isinstance(metrics, dict):
            print(f"  {tag}: Precision={metrics['precision']:.4f}, Recall={metrics['recall']:.4f}, F1={metrics['f1-score']:.4f}")

    # 计算总体F1
    overall_precision = precision_score(all_true_tags, all_pred_tags)
    overall_recall = recall_score(all_true_tags, all_pred_tags)
    overall_f1 = f1_score(all_true_tags, all_pred_tags)

    print(f"\nOverall Entity-Level Metrics:")
    print(f"  Precision: {overall_precision:.4f}")
    print(f"  Recall: {overall_recall:.4f}")
    print(f"  F1: {overall_f1:.4f}")

    # 保存结果
    os.makedirs('../outputs/logs', exist_ok=True)
    model_type = 'crf' if args.use_crf else 'linear'
    result_path = f'../outputs/logs/eval_{model_type}_{args.split}.json'

    results = {
        'model': f"BERT+{'CRF' if args.use_crf else 'Linear'}",
        'split': args.split,
        'precision': float(overall_precision),
        'recall': float(overall_recall),
        'f1': float(overall_f1),
        'illegal_stats': {
            'illegal_start': int(illegal_stats['illegal_start']),
            'illegal_transition': int(illegal_stats['illegal_transition']),
            'total_seqs': int(illegal_stats['total_seqs']),
            'total_illegal': int(illegal_stats['total_illegal']),
        }
    }

    with open(result_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"\nResults saved to {result_path}")

    return results


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Evaluate BERT NER model')
    parser.add_argument('--pretrained_model_path', type=str,
                        default='../pretrain_models/bert-base-chinese',
                        help='Pretrained BERT model path')
    parser.add_argument('--model_dir', type=str,
                        default='../outputs/models',
                        help='Model directory')
    parser.add_argument('--model_name', type=str,
                        default='bert_ner',
                        help='Model name')
    parser.add_argument('--use_crf', action='store_true',
                        help='Use CRF layer')
    parser.add_argument('--split', type=str, default='test',
                        choices=['train', 'validation', 'test'],
                        help='Data split to evaluate')
    parser.add_argument('--max_length', type=int, default=128,
                        help='Max sequence length')
    parser.add_argument('--batch_size', type=int, default=16,
                        help='Batch size')
    parser.add_argument('--dropout', type=float, default=0.1,
                        help='Dropout rate')

    args = parser.parse_args()

    evaluate(args)