"""
NER 数据集类：DataLoader 工厂函数统一封装
模型训练时调用回去封装好的数据集
"""

import json
import torch
from torch.utils.data import Dataset
from transformers import BertTokenizerFast


class NERDataset(Dataset):
    """NER数据集，加载tokens和ner_tags，转换为模型输入"""

    def __init__(self, data_path: str, tokenizer: BertTokenizerFast, max_length: int = 128):
        """
        Args:
            data_path: JSON数据文件路径
            tokenizer: BERT分词器（必须使用fast版本支持word_ids）
            max_length: 最大序列长度
        """
        with open(data_path, encoding='utf-8') as f:
            self.data = json.load(f)

        self.tokenizer = tokenizer
        self.max_length = max_length

        # 构建tag到id的映射
        self.tags = ['O', 'B-PER', 'I-PER', 'B-LOC', 'I-LOC', 'B-ORG', 'I-ORG']
        self.tag2id = {tag: i for i, tag in enumerate(self.tags)}
        self.id2tag = {i: tag for i, tag in enumerate(self.tags)}

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]
        tokens = item['tokens']
        ner_tags = item['ner_tags']

        # 对tokens进行分词（BERT分词器会处理子词）
        tokenized = self.tokenizer(
            tokens,
            is_split_into_words=True,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        input_ids = tokenized['input_ids'].squeeze(0)
        attention_mask = tokenized['attention_mask'].squeeze(0)

        # 对齐labels：需要将子词对应的label设为-100（忽略）
        labels = []
        word_ids = tokenized.word_ids(batch_index=0)
        previous_word_idx = None
        for word_idx in word_ids:
            if word_idx is None:
                labels.append(-100)
            elif word_idx != previous_word_idx:
                # 子词中的第一个，保持原始label
                labels.append(self.tag2id.get(ner_tags[word_idx], 0))
            else:
                # 子词中的后续部分，设为-100
                labels.append(-100)
            previous_word_idx = word_idx

        labels = torch.tensor(labels, dtype=torch.long)

        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'labels': labels
        }


def collate_fn(batch):
    """DataLoader的collate函数"""
    input_ids = torch.stack([item['input_ids'] for item in batch])
    attention_mask = torch.stack([item['attention_mask'] for item in batch])
    labels = torch.stack([item['labels'] for item in batch])

    return {
        'input_ids': input_ids,
        'attention_mask': attention_mask,
        'labels': labels
    }