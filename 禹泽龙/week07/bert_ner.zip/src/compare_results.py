"""
汇总所有方案的评估结果，打印对比表

使用方式：
  python compare_results.py

功能：
  1. 训练日志对比（train_linear_log.json / train_crf_log.json）
     - 各epoch的train_loss、val_entity_f1
     - 最优F1、最优epoch、训练时间
  2. 测试集评估结果对比（eval_linear_test.json / eval_crf_test.json）
     - entity-level P/R/F1
     - 非法序列统计
"""

import json
import os
from pathlib import Path

ROOT = Path(__file__).parent.parent
LOG_DIR = ROOT / "outputs" / "logs"


def load_json(path):
    """加载JSON文件"""
    if os.path.exists(path):
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    return None


def print_training_logs(logs):
    """打印训练日志"""
    if not logs:
        return None

    print("\n" + "=" * 80)
    print("Training Logs".center(80))
    print("=" * 80)

    # 表头
    header = f"{'Epoch':<8} {'Train Loss':<12} {'Val Loss':<12} {'Val Entity F1':<15} {'Time(s)':<10}"
    print(header)
    print("-" * 80)

    best_f1 = 0
    best_epoch = 0
    for record in logs:
        epoch = record.get('epoch', '-')
        train_loss = record.get('train_loss', 0)
        val_loss = record.get('val_loss', 0)
        val_f1 = record.get('val_entity_f1', 0)
        elapsed = record.get('elapsed_s', 0)

        marker = ""
        if val_f1 > best_f1:
            best_f1 = val_f1
            best_epoch = epoch
            marker = " ★"

        print(f"{epoch:<8} {train_loss:<12.6f} {val_loss:<12.6f} {val_f1:<15.4f} {elapsed:<10.1f}{marker}")

    print("-" * 80)
    print(f"Best: Epoch {best_epoch}, Val F1 = {best_f1:.4f}")

    return {'best_f1': best_f1, 'best_epoch': best_epoch, 'records': logs}


def print_eval_results(results):
    """打印评估结果对比表"""
    print("\n" + "=" * 80)
    print("Test Set Evaluation Results (Entity-Level)".center(80))
    print("=" * 80)

    # 表头
    header = f"{'Model':<20} {'Precision':<12} {'Recall':<12} {'F1':<12} {'Illegal Seq.':<15} {'Illegal Rate':<12}"
    print(header)
    print("-" * 80)

    for model_name, result in results.items():
        if result:
            prec = result.get('precision', 0)
            rec = result.get('recall', 0)
            f1 = result.get('f1', 0)
            illegal = result.get('illegal_count', 0)
            illegal_rate = result.get('illegal_rate', 0)

            row = f"{model_name:<20} {prec:<12.4f} {rec:<12.4f} {f1:<12.4f} {illegal:<15} {illegal_rate*100:<12.2f}%"
            print(row)

    print("=" * 80)


def print_detailed_analysis(training_info, eval_results):
    """打印详细对比分析"""
    if not training_info or not eval_results:
        return

    print("\n" + "=" * 80)
    print("Detailed Analysis".center(80))
    print("=" * 80)

    linear_train = training_info.get('linear')
    crf_train = training_info.get('crf')
    linear_eval = eval_results.get('BERT+Linear')
    crf_eval = eval_results.get('BERT+CRF')

    if linear_train and crf_train:
        linear_best_f1 = linear_train['best_f1']
        crf_best_f1 = crf_train['best_f1']
        f1_diff = crf_best_f1 - linear_best_f1

        print(f"\n训练过程对比:")
        print(f"  BERT+Linear: Best F1={linear_best_f1:.4f} (Epoch {linear_train['best_epoch']})")
        print(f"  BERT+CRF:    Best F1={crf_best_f1:.4f} (Epoch {crf_train['best_epoch']})")
        print(f"  F1差异:       {f1_diff:+.4f}")

    if linear_eval and crf_eval:
        illegal_diff = linear_eval.get('illegal_count', 0) - crf_eval.get('illegal_count', 0)

        print(f"\n测试集评估对比:")
        print(f"  BERT+Linear: F1={linear_eval.get('f1', 0):.4f}, Illegal={linear_eval.get('illegal_count', 0)}")
        print(f"  BERT+CRF:    F1={crf_eval.get('f1', 0):.4f}, Illegal={crf_eval.get('illegal_count', 0)}")
        print(f"  非法序列消除: {illegal_diff}")

        if f1_diff > 0:
            print(f"\n结论: CRF在F1和合法序列上都更优")
        else:
            print(f"\n结论: Linear在F1上更优，但会产生非法序列")


def main():
    # 使用脚本所在目录构建绝对路径
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    # 加载训练日志
    print("\n" + "=" * 80)
    print("Train Logs Comparison".center(80))
    print("=" * 80)

    training_info = {}

    linear_log = load_json(LOG_DIR / "train_linear_log.json")
    if linear_log:
        print("\n【BERT+Linear 训练日志】")
        info = print_training_logs(linear_log)
        training_info['linear'] = info

    crf_log = load_json(LOG_DIR / "train_crf_log.json")
    if crf_log:
        print("\n【BERT+CRF 训练日志】")
        info = print_training_logs(crf_log)
        training_info['crf'] = info

    if not training_info:
        print("\n未找到训练日志！请先运行 train.py:")
        print("  python train.py --model_name bert_ner")
        print("  python train.py --use_crf --model_name bert_crf")

    # 加载评估结果
    eval_results = {}

    linear_eval = load_json(os.path.join(LOG_DIR, 'eval_linear_test.json'))
    if linear_eval:
        eval_results['BERT+Linear'] = linear_eval

    crf_eval = load_json(os.path.join(LOG_DIR, 'eval_crf_test.json'))
    if crf_eval:
        eval_results['BERT+CRF'] = crf_eval

    # LLM结果（如果存在）
    llm_eval = load_json(os.path.join(LOG_DIR, 'eval_llm.json'))
    if llm_eval:
        eval_results['LLM'] = llm_eval

    if eval_results:
        print_eval_results(eval_results)
    else:
        print("\n未找到评估结果！请先运行 evaluate.py:")
        print("  python evaluate.py --model_name bert_ner --split test")
        print("  python evaluate.py --use_crf --model_name bert_crf --split test")

    # 详细分析
    print_detailed_analysis(training_info, eval_results)

    print("\n" + "=" * 80)
    print("Done!".center(80))
    print("=" * 80)


if __name__ == '__main__':
    main()