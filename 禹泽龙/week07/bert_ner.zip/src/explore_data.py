"""
  1. 各实体类型的分布差异（为什么类别不均衡是NER的难点）
  2. 文本长度分布（影响 BERT max_length 的选择）
  3. 实体长度分布（短实体 vs 长实体的识别难度差异）

使用方式：
  python explore_data.py

输出：
  outputs/figures/entity_distribution.png   各类实体频次分布
  outputs/figures/text_length_distribution.png  文本长度分布
  outputs/figures/entity_length_distribution.png 实体长度分布
"""

import json
import os
import matplotlib.pyplot as plt
from collections import Counter

plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


def load_data(data_path):
    """加载JSON数据"""
    with open(data_path, encoding='utf-8') as f:
        return json.load(f)


def analyze_entity_distribution(data):
    """分析各实体类型的分布"""
    entity_counter = Counter()

    for item in data:
        ner_tags = item['ner_tags']
        for tag in ner_tags:
            if tag != 'O':
                entity_counter[tag] += 1

    return entity_counter


def analyze_text_length(data):
    """分析文本长度分布"""
    return [len(item['tokens']) for item in data]


def analyze_entity_length(data):
    """分析实体长度分布"""
    entity_lengths = []

    for item in data:
        ner_tags = item['ner_tags']
        current_length = 0
        current_type = None

        for tag in ner_tags:
            if tag == 'O':
                if current_type is not None:
                    entity_lengths.append(current_length)
                    current_length = 0
                    current_type = None
            elif tag.startswith('B-'):
                if current_type is not None:
                    entity_lengths.append(current_length)
                current_length = 1
                current_type = tag[2:]
            elif tag.startswith('I-'):
                current_length += 1

        if current_type is not None:
            entity_lengths.append(current_length)

    return entity_lengths


def plot_and_save(x, y, title, xlabel, ylabel, save_path, color='steelblue'):
    """绘制并保存图表"""
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    plt.figure(figsize=(10, 6))
    plt.bar(x, y, color=color)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f"Saved to {save_path}")


def plot_histogram(data, title, xlabel, ylabel, save_path, bins=50, color='steelblue'):
    """绘制直方图"""
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    plt.figure(figsize=(10, 6))
    plt.hist(data, bins=bins, color=color, edgecolor='black', alpha=0.7)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f"Saved to {save_path}")


def main():
    # 获取脚本所在目录的绝对路径
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.dirname(script_dir)

    # 加载训练数据
    data_path = os.path.join(project_dir, 'data', 'train.json')
    data = load_data(data_path)

    print(f"Loaded {len(data)} samples from {data_path}")

    # 1. 实体类型分布
    entity_counter = analyze_entity_distribution(data)
    print("\nEntity Distribution:")
    for entity, count in entity_counter.most_common():
        print(f"  {entity}: {count}")

    entities = [e for e, _ in entity_counter.most_common()]
    counts = [c for _, c in entity_counter.most_common()]

    plot_and_save(
        entities, counts,
        'Entity Type Distribution',
        'Entity Type',
        'Count',
        os.path.join(project_dir, 'outputs', 'figures', 'entity_distribution.png')
    )

    # 2. 文本长度分布
    text_lengths = analyze_text_length(data)
    print(f"\nText Length Stats:")
    print(f"  Min: {min(text_lengths)}, Max: {max(text_lengths)}")
    print(f"  Mean: {sum(text_lengths)/len(text_lengths):.2f}")

    plot_histogram(
        text_lengths,
        'Text Length Distribution',
        'Text Length (tokens)',
        'Count',
        os.path.join(project_dir, 'outputs', 'figures', 'text_length_distribution.png')
    )

    # 3. 实体长度分布
    entity_lengths = analyze_entity_length(data)
    if entity_lengths:
        print(f"\nEntity Length Stats:")
        print(f"  Min: {min(entity_lengths)}, Max: {max(entity_lengths)}")
        print(f"  Mean: {sum(entity_lengths)/len(entity_lengths):.2f}")

        plot_histogram(
            entity_lengths,
            'Entity Length Distribution',
            'Entity Length (tokens)',
            'Count',
            os.path.join(project_dir, 'outputs', 'figures', 'entity_length_distribution.png')
        )

    print("\nAnalysis complete!")


if __name__ == '__main__':
    main()