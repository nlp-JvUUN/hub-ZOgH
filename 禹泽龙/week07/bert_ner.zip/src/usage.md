# 先训练两个模型
python train.py --model_name bert_ner
python train.py --use_crf --model_name bert_crf

# 再评估
python evaluate.py --model_name bert_ner --split test
python evaluate.py --use_crf --model_name bert_crf --split test

# 最后对比结果
python compare_results.py
